# passpulse/policies.py
"""Predefined policies for PassPulse with clear rules that affect scoring."""

from typing import Dict

def basic_policy() -> Dict:
    return {
        "name": "basic",
        "min_length": 8,
        "min_entropy": 28,     # bits
        "class_min": 2,        # πόσες κατηγορίες από: lower, upper, digit, special
        "require_lower": False,
        "require_upper": False,
        "require_digit": False,
        "require_special": False,
        "banned_words": [],
    }

def strict_policy() -> Dict:
    return {
        "name": "strict",
        "min_length": 12,
        "min_entropy": 40,
        "class_min": 3,
        "require_lower": True,
        "require_upper": True,
        "require_digit": True,
        "require_special": True,
        "banned_words": ["password", "admin", "qwerty", "1234", "letmein"],
    }

def nist_like_policy() -> Dict:
    # απλοποιημένη εκδοχή: δίνει έμφαση στο μήκος/εντροπία, όχι σε υποχρεωτικές κλάσεις
    return {
        "name": "nist",
        "min_length": 12,
        "min_entropy": 36,
        "class_min": 2,
        "require_lower": False,
        "require_upper": False,
        "require_digit": False,
        "require_special": False,
        "banned_words": [],
    }

ALL_POLICIES = {
    "basic": basic_policy(),
    "strict": strict_policy(),
    "nist": nist_like_policy(),
}
