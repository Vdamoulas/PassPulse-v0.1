# PassPulse

PassPulse — Password strength checker (GUI + engine + generator)  
Privacy-first, local-only evaluation, policies, CSV export.

## Quickstart (dev)
1. Python 3.10+
2. Create venv and install:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # Linux/Mac:
   source .venv/bin/activate
   pip install -e .
   ```
3. Run GUI:
   ```bash
   python -m app.gui
   ```
   or via console script:
   ```bash
   passpulse-gui
   ```

## Features
- Scoring engine (entropy, variety, blacklist)
- Preset policies (basic/strict/nist-like)
- Password & passphrase generator
- GUI (Tkinter) + CSV export

## Packaging (optional)
- Build Windows exe:
  ```bash
  pip install pyinstaller
  pyinstaller --noconsole --name PassPulse --icon app/assets/icon.ico app/gui.py
  ```

## License
MIT
