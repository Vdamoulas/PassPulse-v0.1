"""
PassPulse — Professional Dashboard Edition
Tkinter + ttkbootstrap
"""
# --- resource helper for PyInstaller (put this at top of app/gui.py) ---
import sys, pathlib, json

def resource_path(relpath: str) -> pathlib.Path:
    """Return absolute path to resource, works in dev and in PyInstaller onefile."""
    if getattr(sys, "frozen", False):
        base = pathlib.Path(sys._MEIPASS)
    else:
        base = pathlib.Path(__file__).resolve().parents[1]
    return base / relpath

# Example usage:
# SETTINGS_PATH = resource_path("settings.json")
# with open(SETTINGS_PATH, "r", encoding="utf-8") as f: settings = json.load(f)

import sys, pathlib, csv, time, tkinter as tk
from tkinter import ttk, messagebox, filedialog

# --- relative imports for project structure ---
ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from passpulse.engine import evaluate
from passpulse.generator import generate_password, generate_passphrase
from passpulse.policies import ALL_POLICIES

# --- bootstrap import ---
import ttkbootstrap as tb
try:
    from ttkbootstrap.widgets import Switch
except Exception:
    class Switch(tb.Checkbutton):
        def __init__(self, master=None, **kwargs):
            kwargs.setdefault("text", "")
            kwargs.setdefault("bootstyle", "secondary-toolbutton")
            super().__init__(master, **kwargs)

APP_TITLE = "PassPulse — Password Strength Pro"


# --- splash screen ---
class Splash(tb.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("")
        self.overrideredirect(True)
        self.geometry("400x280+600+280")
        self.configure(bg="#0d1117")
        lbl = tk.Label(
            self, text="PassPulse", font=("Segoe UI", 22, "bold"),
            bg="#0d1117", fg="#58a6ff"
        )
        lbl.pack(pady=80)
        sub = tk.Label(
            self, text="Loading professional dashboard...",
            font=("Segoe UI", 10), bg="#0d1117", fg="#b3b3b3"
        )
        sub.pack()
        bar = ttk.Progressbar(self, mode="indeterminate", length=280)
        bar.pack(pady=50)
        bar.start(10)
        self.update()


# --- main app ---
class App(tb.Window):
    def __init__(self):
        super().__init__(title=APP_TITLE, themename="darkly")  # ✅ no conflict

        self.geometry("1200x740")
        self.minsize(1000, 640)

        # variables
        self.theme_dark = tk.BooleanVar(value=True)
        self.policy_var = tk.StringVar(value="basic")
        self.length_var = tk.IntVar(value=14)
        self.pw_var = tk.StringVar()

        # ✅ Αυτόματη ενημέρωση UI όταν αλλάζει policy
        self.policy_var.trace_add("write", lambda *_: self.update_ui())

        # build UI
        self._build_topbar()
        self._build_body()
        self._build_status()

        # splash
        self.withdraw()
        s = Splash(self)
        self.after(1000, lambda: (self.deiconify(), s.destroy() if s.winfo_exists() else None))
        self.update_ui()

    # --- header ---
    def _build_topbar(self):
        top = ttk.Frame(self, padding=(10, 6))
        top.pack(fill=tk.X)

        title = ttk.Label(top, text="🔐 PassPulse", font=("Segoe UI", 18, "bold"))
        title.pack(side=tk.LEFT, padx=(10, 20))

        about_btn = ttk.Button(top, text="About", command=self._on_about, bootstyle="secondary-outline")
        about_btn.pack(side=tk.RIGHT, padx=(8, 4))

        sw = Switch(top, variable=self.theme_dark, bootstyle="primary")
        sw.pack(side=tk.RIGHT, padx=(8, 4))
        ttk.Label(top, text="Dark mode").pack(side=tk.RIGHT, padx=(4, 2))
        self.theme_dark.trace_add("write", lambda *_: self._toggle_theme())

    # --- body ---
    def _build_body(self):
        body = ttk.Frame(self, padding=20)
        body.pack(fill=tk.BOTH, expand=True)

        # left column
        left = ttk.Labelframe(body, text="Password Evaluation", padding=20)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        ttk.Label(left, text="Κωδικός / Passphrase", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.entry = ttk.Entry(left, textvariable=self.pw_var, show="*")
        self.entry.pack(fill=tk.X, pady=6)
        self.entry.bind("<KeyRelease>", lambda e: self.update_ui())

        self.show_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(left, text="Εμφάνιση", variable=self.show_var,
                        command=self._toggle_show).pack(anchor="e", pady=(0, 10))

        ttk.Label(left, text="Policy:").pack(anchor="w")

        # ✅ Πολιτικές με αυτόματο refresh UI
        for key, label in [("basic", "Basic"), ("strict", "Strict"), ("nist", "NIST")]:
            ttk.Radiobutton(
                left,
                text=label,
                variable=self.policy_var,
                value=key,
                command=self.update_ui
            ).pack(anchor="w")

        # buttons row
        btns = ttk.Frame(left)
        btns.pack(fill=tk.X, pady=10)
        ttk.Button(btns, text="Έλεγχος", command=self.manual_check, bootstyle="success").pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Generate Password", command=self.on_generate_pw, bootstyle="info").pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Generate Passphrase", command=self.on_generate_pp, bootstyle="info").pack(side=tk.LEFT, padx=4)

        # progress
        self.progress = ttk.Progressbar(left, mode="determinate", maximum=100, bootstyle="info")
        self.progress.pack(fill=tk.X, pady=10)

        self.cat_label = ttk.Label(left, text="Κατάσταση: —", font=("Segoe UI", 10, "bold"))
        self.cat_label.pack(anchor="w", pady=(4, 2))

        ttk.Label(left, text="Σχόλια / Προτάσεις").pack(anchor="w", pady=(6, 2))
        self.reason_text = tk.Text(left, height=8, wrap="word", font=("Segoe UI", 10))
        self.reason_text.pack(fill=tk.BOTH, expand=True)

        # right column
        right = ttk.Labelframe(body, text="Utilities", padding=20)
        right.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Button(right, text="Copy Password", command=self.copy_to_clipboard, bootstyle="primary-outline").pack(fill=tk.X, pady=4)
        ttk.Button(right, text="Export CSV", command=self.export_csv, bootstyle="secondary-outline").pack(fill=tk.X, pady=4)

        ttk.Label(right, text="Entropy / Time to crack", font=("Segoe UI", 10, "bold")).pack(pady=(20, 4))
        self.entropy_label = ttk.Label(right, text="Entropy: — bits")
        self.ttc_label = ttk.Label(right, text="TTC: —")
        self.entropy_label.pack(anchor="w")
        self.ttc_label.pack(anchor="w")

    # --- status ---
    def _build_status(self):
        bar = ttk.Frame(self, padding=6)
        bar.pack(fill=tk.X, side=tk.BOTTOM)
        ttk.Label(bar, text="MIT License — PassPulse Pro v1.1", font=("Segoe UI", 9)).pack(side=tk.LEFT)

    # --- actions ---
    def _on_about(self):
        messagebox.showinfo(APP_TITLE, "PassPulse Pro\nModern UI edition with ttkbootstrap.")

    def _toggle_theme(self):
        if self.theme_dark.get():
            self.style.theme_use("darkly")
        else:
            self.style.theme_use("flatly")
        self.update_ui()

    def _toggle_show(self):
        self.entry.configure(show="" if self.show_var.get() else "*")

    def update_ui(self):
        pw = self.pw_var.get()
        policy = ALL_POLICIES.get(self.policy_var.get(), {})
        res = evaluate(pw, policy)
        score = res.get("score", 0)

        style = "danger" if score < 30 else "warning" if score < 60 else "success"
        self.progress.configure(value=score, bootstyle=style)
        self.cat_label.configure(text=f"Κατάσταση: {res['category']} — {score}%")
        self.entropy_label.configure(text=f"Entropy: {res.get('entropy_bits', 0)} bits")
        self.ttc_label.configure(text=f"TTC: {self._format_ttc(res.get('ttc_seconds', 0))}")

        self.reason_text.configure(state="normal")
        self.reason_text.delete("1.0", tk.END)
        for r in res.get("reasons", []):
            self.reason_text.insert(tk.END, f"• {r}\n")
        self.reason_text.configure(state="disabled")

    def manual_check(self):
        pw = self.pw_var.get()
        if not pw:
            messagebox.showinfo(APP_TITLE, "Πληκτρολόγησε κωδικό πρώτα.")
            return
        self.update_ui()
        res = evaluate(pw, ALL_POLICIES.get(self.policy_var.get(), {}))
        messagebox.showinfo(APP_TITLE, f"Κατηγορία: {res['category']}\nScore: {res['score']}%\nEntropy: {res['entropy_bits']} bits")

    def on_generate_pw(self):
        pw = generate_password(length=self.length_var.get(), use_upper=True, use_digits=True, use_special=True)
        self.pw_var.set(pw)
        self.update_ui()

    def on_generate_pp(self):
        pp = generate_passphrase(words=4, separator="-")
        self.pw_var.set(pp)
        self.update_ui()

    def copy_to_clipboard(self):
        self.clipboard_clear()
        self.clipboard_append(self.pw_var.get())
        messagebox.showinfo(APP_TITLE, "Αντιγράφηκε στο clipboard.")

    def export_csv(self):
        pw = self.pw_var.get()
        policy = ALL_POLICIES.get(self.policy_var.get(), {})
        res = evaluate(pw, policy)
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="passpulse_report.csv",
                                            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["password","score","category","entropy_bits","ttc_seconds","policy"])
            w.writerow([pw, res["score"], res["category"], res["entropy_bits"], res["ttc_seconds"], policy.get("name")])
        messagebox.showinfo(APP_TITLE, f"Exported: {path}")

    @staticmethod
    def _format_ttc(seconds: float) -> str:
        if not seconds or seconds <= 0: return "<1s"
        units = [("years", 31536000), ("days", 86400), ("hours", 3600), ("minutes", 60), ("seconds", 1)]
        parts, remain = [], float(seconds)
        for name, val in units:
            if remain >= val:
                qty = int(remain // val)
                parts.append(f"{qty} {name}")
                remain -= qty * val
        return ", ".join(parts[:2]) if parts else "<1s"


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
