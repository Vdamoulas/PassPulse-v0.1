# passpulse/generator.py
"""Password & passphrase generator."""
import secrets
import string
from typing import List

WORDLIST_SAMPLE = [
    "apple","river","storm","mirror","stone","lucky","quantum","neon",
    "orbit","delta","crane","pixel","ember","sigma","atlas","nova"
]

def generate_password(length: int = 12, use_upper=True, use_digits=True, use_special=True) -> str:
    charset = string.ascii_lowercase
    if use_upper:
        charset += string.ascii_uppercase
    if use_digits:
        charset += string.digits
    if use_special:
        charset += "!@#$%^&*()-_=+[]{};:,.<>/?"
    # ensure at least one of each selected class
    while True:
        pw = ''.join(secrets.choice(charset) for _ in range(length))
        # simple policy: contains required classes
        if use_upper and not any(c.isupper() for c in pw):
            continue
        if use_digits and not any(c.isdigit() for c in pw):
            continue
        if use_special and not any(c in "!@#$%^&*()-_=+[]{};:,.<>/?" for c in pw):
            continue
        return pw

def generate_passphrase(words: int = 4, separator: str = "-") -> str:
    return separator.join(secrets.choice(WORDLIST_SAMPLE) for _ in range(words))
