# passpulse/engine.py
"""Core scoring engine for PassPulse with policy-aware penalties."""
import re
import math
from typing import Dict, List, Tuple

COMMON_PASSWORDS = {
    "123456","password","123456789","qwerty","12345678","111111","1234567",
    "dragon","123123","baseball","iloveyou","trustno1","1234","000000"
}

def _classes_present(pw: str) -> Tuple[bool,bool,bool,bool]:
    lower = bool(re.search(r"[a-zα-ω]", pw))
    upper = bool(re.search(r"[A-ZΑ-Ω]", pw))
    digit = bool(re.search(r"\d", pw))
    special = bool(re.search(r"[^\w\s]", pw))
    return lower, upper, digit, special

def entropy_bits(password: str) -> float:
    if not password:
        return 0.0
    charset = 0
    if re.search(r"[a-zα-ω]", password): charset += 26
    if re.search(r"[A-ZΑ-Ω]", password): charset += 26
    if re.search(r"\d", password): charset += 10
    if re.search(r"[^\w\s]", password): charset += 32
    if charset == 0: charset = 94
    return math.log2(charset) * len(password)

def time_to_crack_seconds(ent_bits: float, guesses_per_second: float = 1e9) -> float:
    return (2 ** max(0, ent_bits - 1)) / guesses_per_second

def evaluate(password: str, policy: Dict | None = None) -> Dict:
    """Return scoring with policy impact."""
    if policy is None:
        policy = {}

    pw = password or ""
    reasons: List[str] = []
    score = 0

    if not pw:
        return {"score": 0, "category": "Καθόλου", "reasons": ["Κενός κωδικός."],
                "entropy_bits": 0.0, "ttc_seconds": 0.0, "policy_pass": False}

    n = len(pw)
    lw = pw.lower()

    # ---- Base scoring (όπως πριν) ----
    if lw in COMMON_PASSWORDS or n <= 3:
        reasons.append("Πολύ κοινός ή υπερβολικά κοντός κωδικός.")
        score -= 40

    # length
    if n >= 12: score += 30
    elif n >= 8: score += 15
    else:
        score += 5
        reasons.append("Συνιστάται μήκος ≥ 8–12 χαρακτήρες.")

    lower, upper, digit, special = _classes_present(pw)
    if lower: score += 10
    else: reasons.append("Πρόσθεσε μικρό γράμμα.")
    if upper: score += 10
    else: reasons.append("Πρόσθεσε κεφαλαίο γράμμα.")
    if digit: score += 10
    else: reasons.append("Πρόσθεσε ψηφίο.")
    if special: score += 15
    else: reasons.append("Πρόσθεσε ειδικό χαρακτήρα (π.χ. !@#$).")

    # simple penalties
    if re.search(r"(.)\1\1", pw):
        score -= 10
        reasons.append("Απέφυγε 3+ ίδιους συνεχόμενους χαρακτήρες.")
    for seq in ["abcdefghijklmnopqrstuvwxyz","0123456789"]:
        for i in range(len(seq)-3):
            if seq[i:i+4] in lw:
                score -= 10
                reasons.append("Απέφυγε απλές ακολουθίες (abcd/1234).")
                break

    # entropy & ttc (δεν εξαρτώνται από policy)
    ent = entropy_bits(pw)
    ttc = time_to_crack_seconds(ent)
    if ent >= 60: score += 25
    elif ent >= 40: score += 10
    elif ent < 28:
        score -= 10
        reasons.append("Χαμηλή εντροπία → ευάλωτος σε brute force.")

    # ---- Policy enforcement (εδώ θα δεις τη διαφορά) ----
    pol_reasons = []
    pol_pass = True

    min_len = policy.get("min_length")
    if isinstance(min_len, int) and n < min_len:
        pol_pass = False
        pol_reasons.append(f"[Policy] Μήκος < {min_len}.")
        score -= 35

    min_ent = policy.get("min_entropy")
    if isinstance(min_ent, (int, float)) and ent < float(min_ent):
        pol_pass = False
        pol_reasons.append(f"[Policy] Entropy < {min_ent} bits.")
        score -= 25

    class_min = policy.get("class_min", 0)
    cls_count = sum([lower, upper, digit, special])
    if class_min and cls_count < class_min:
        pol_pass = False
        pol_reasons.append(f"[Policy] Χρειάζονται ≥ {class_min} κατηγορίες, έχεις {cls_count}.")
        score -= 15

    # required flags
    reqs = [
        ("require_lower", lower, "μικρό γράμμα"),
        ("require_upper", upper, "κεφαλαίο γράμμα"),
        ("require_digit", digit, "ψηφίο"),
        ("require_special", special, "ειδικό χαρακτήρα"),
    ]
    for key, ok, label in reqs:
        if policy.get(key) and not ok:
            pol_pass = False
            pol_reasons.append(f"[Policy] Απαιτείται {label}.")
            score -= 10

    # banned words
    for w in policy.get("banned_words", []):
        if w and w.lower() in lw:
            pol_pass = False
            pol_reasons.append("[Policy] Περιέχει απαγορευμένη λέξη/φράση.")
            score -= 30
            break

    # reasons merge (policy first για να φαίνονται)
    reasons = pol_reasons + reasons

    # clamp & category
    score = max(0, min(100, int(score)))
    if score < 20: cat = "Καθόλου"
    elif score < 40: cat = "Λίγο"
    elif score < 60: cat = "Μέτρια"
    elif score < 80: cat = "Πολύ"
    else: cat = "Πάρα πολύ (Strong)"

    return {
        "score": score,
        "category": cat,
        "reasons": reasons or ["Φαίνεται ΟΚ, αλλά έλεγξε τις συστάσεις."],
        "entropy_bits": round(ent, 2),
        "ttc_seconds": ttc,
        "policy_pass": pol_pass,
    }
